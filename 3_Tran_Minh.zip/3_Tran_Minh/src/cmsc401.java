
/////////////////////////////////////////////////
//     Minh Matthew Tran                       //
//     CMSC 401 Fall 2017                      //
//     Assignment #3                           //
/////////////////////////////////////////////////

import java.util.Scanner;

public class cmsc401 {
	 static Node next;
	 static Node prev;

	public static void main(String[] args) {
		cmsc401 tree = new cmsc401();

		Scanner input = new Scanner(System.in);

		int n = input.nextInt()+1;
		int m = input.nextInt();
		int[] s = new int[n];
		int[] w = new int[m];
		int count = 0;

		for (int i = 1; i < n; i++) {
			s[i] = input.nextInt();
		}

		for (int i = 0; i < m; i++) {
			w[i] = input.nextInt();
		}

		Node node = tree.arrayBST(s, 0, s.length - 1);

		// counts how many times w[i] value is in bound with s
		for (int i = 0; i < w.length; i++) {
			if (w[i] < s[n - 1] && w[i] > s[0]) {
				count++;
			}
		}
		System.out.println(count);

		// searches in log n time
		for (int i = 0; i < w.length; i++) {
			tree.search(node, w[i]);

		}

	}



// ~~~~~Node Class~~~~~
class Node {
	int data;
	Node left, right;
	Node next, prev;

	public Node() {
		left = null;
		right = null;
		next = null;
		prev = null;
		data = 0;
		
	}

	Node(int data) {
		left = null;
		right = null;
		next = null;
		prev = null;
		this.data = data;
	}
}

	public boolean isEmpty() {
		return root == null;
	}

Node root;

Node arrayBST(int array[], int start, int end) {

		if (start > end) {
			return null;
		}

		int mid = (start + end) / 2;

		Node node = new Node(array[mid]);

		node.left = arrayBST(array, start, mid - 1);
		node.right = arrayBST(array, mid + 1, end);

		return node;
	}

Node search(Node node, int d) {

if(isEmpty()){
	
}

if (node.data > d) {
	if (node.left == null) {
		next = node;
		System.out.println(prev.data + 1 + " " + next.data);
		return null;
	}
 else {
	next = node;
	node = node.left;
	return search(node, d);
 }
}

if(node.data < d){
	if(node.right == null){
		prev = node;
		System.out.println(prev.data + 1 + " " + next.data);
		return null;
	}else{
		prev = node;
		node = node.right;
		return search(node, d);
	}
}

if(node.data == d || node == null){
	if(node.left != null){
		prev = node.left;
		System.out.println(prev.data + 1 + " " + node.data);
		return null;
	}else{
		System.out.println(prev.data + 1 + " " + node.data);
		return null;
	}
}
	
	return null;
	
}

}
/*
 * 5 3 100 147 200 257 290 55 121 268 3 2 25 33 74 19 40
 */