    /////////////////////////////////////////////////
	//     Minh Matthew Tran                       //
	//     CMSC 401 Fall 2017                      //
	//     Assignment #2                           //
	/////////////////////////////////////////////////
import java.util.*;
import java.math.*;

public class cmsc401 {
	public static int quickS(int[] yArray, int left, int right, int p){
		int pIndex = partition(yArray, left, right);

		//////////////////////////////////////////////////////////////
//		System.out.println("p is: " + p + " pIndex is: " + pIndex);
//		for(int i =0; i<yArray.length;i++){
//			System.out.println("position:" + i + " - " + yArray[i]);
//		}
		/////////////////////////////////////////////////////
		if(p==pIndex){
			return yArray[p];
		}else if(p>pIndex){
			return quickS(yArray,pIndex+1,right,p);
		}else{
			return quickS(yArray,left,pIndex-1,p);
		}
	}
	
	private static int partition(int[] array, int left, int right){
		int pIndex = (int)(Math.random() * (right-left+1)) + left;
		swap(array,right,pIndex);
		for(int i = left; i<right;i++){
			if(array[i]>array[right]){
				swap(array,i,left);
				left++;
			}
		}
		swap(array,left,right);
		return left;
	}
	private static void swap(int[] array, int a, int b){
	        int temp = array[a];
	        array[a] = array[b];
	        array[b] = temp;
	    }

	
	public static void main(String[] args){
	Scanner input = new Scanner(System.in);
	//System.out.println("Enter # of houses: ");
	int numHouses = input.nextInt(); 
	int[] yArray = new int[numHouses];
	
	
	//entering y cords
	for(int i=0;i<yArray.length;i++){
		//System.out.println("Enter y cord: ");
		yArray[i] = input.nextInt();
	}
	int mid = (yArray.length)/2;
	
	int result = quickS(yArray,0,yArray.length-1,mid);
	System.out.println(result);
	
	
}
}
