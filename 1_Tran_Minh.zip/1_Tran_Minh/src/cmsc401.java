    /////////////////////////////////////////////////
	//     Minh Matthew Tran                       //
	//     CMSC 401 Fall 2017                      //
	//     Assignment #1                           //
	/////////////////////////////////////////////////
import java.util.*;

public class cmsc401 {
	
	public static int[] sort(int[] realArray){
		int[] sortedArray = new int[realArray.length];
		//max and min values of the unsorted array
		int max = realArray[0];
		int min = realArray[0];
		for(int i=1;i<realArray.length;i++){
			if(realArray[i]>max){
				max = realArray[i];
			}
			if(realArray[i]<min){
				min = realArray[i];
			}
		}
		int[] count = new int[max - min + 1];
		for(int i = 0;i<realArray.length;i++){
			count[realArray[i]-min]++;
		}
		count[0]--;
		for(int i = 1;i<count.length;i++){
			count[i] = count[i] + count[i-1];
		}
		for(int i = realArray.length-1;i>=0;i--){
			sortedArray[count[realArray[i]-min]--] = realArray[i];
		}
		return sortedArray;
		}
	
	public static void main(String[] args){
	Scanner input = new Scanner(System.in);
	//System.out.println("How many numbers in ur array?");
	//how many numbers to be sorted
	int num = input.nextInt();
	//System.out.println("Enter limits");
	//what the limits are
	int l = input.nextInt();
	
	int[] numArray = new int[num];
	int many = 0;
	
	for (int n=0; n<numArray.length; n++){
		//System.out.println("enter number");
		//entering numbers
		numArray[n] = input.nextInt();
	}
	
	for(int j=0;j<numArray.length;j++){
		if(numArray[j]>=-l && numArray[j]<=l){
			many++;
		}
		else{}
	}
	
	//checking the bounds for the number given
	//this removes the numbers thats not in the bound given
	//by moving the numbers in the bound into another array
	int[] realArray = new int[many];
	int inArray = 0;
	for(int i=0; i<numArray.length;++i){
		if(numArray[i]>=-l && numArray[i]<=l){
			realArray[inArray] = numArray[i];
			inArray++;
		}
		else{
		}
	}
	
	//sort array method
	int[] result = sort(realArray);
	//*********************************************
	//System.out.println("sorted array");
	//printing sorted array
	for(int t = 0; t<result.length; t++){
		System.out.println(result[t]);
	}
	}
}



