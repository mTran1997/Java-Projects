    /////////////////////////////////////////////////
	//     Minh Matthew Tran                       //
	//     CMSC 401 Fall 2017                      //
	//     Trial Assignment                        //
	/////////////////////////////////////////////////
import java.util.*;

public class cmsc401 {
public static void main(String[] args){
	Scanner input = new Scanner(System.in);
	int numLines = input.nextInt();
	int[] list = new int[numLines];
	int z = 0;
	for (int i = 1; i <= numLines; i++){
		int numArray = input.nextInt();
		int[] numList = new int[numArray];
		for (int n = 0; n < numList.length; n++){
			numList[n] = input.nextInt();
		}
		int finalNum=0;
		int num1 = numList[numList.length-1];
		int num2 = numList[numList.length-2];
		finalNum = numList[num1-1]*numList[num2-1];
		list[z]=finalNum;
		z++;
	}
	if (numLines==z){
		for(int c=0; c<numLines; c++){
			System.out.println(list[c]);
		}
	}
	
}
}
