    /////////////////////////////////////////////////
	//     Minh Matthew Tran                       //
	//     CMSC 401 Fall 2017                      //
	//     Assignment #4                           //
	/////////////////////////////////////////////////

import java.util.*;


public class cmsc401part2 {
	
	int vertNum, edgeNum;
	Edge edge[];
	
	public static void main(String[] args){
		Scanner input = new Scanner(System.in);
		
		int cities = input.nextInt();
		int highways = input.nextInt();
		
		int[] citynum_array = new int[cities-2];
		int[] motelcost_array = new int[cities-2];
		cmsc401part2 graph = new cmsc401part2(cities, highways);
	
		int citynum=0;
		int motelcost=0;
		for(int i = 0; i<citynum_array.length; i++){
			citynum = input.nextInt();
			citynum_array[i] = citynum;
			motelcost = input.nextInt();
			motelcost_array[i] = motelcost;
		}
		
		int[] fromArray = new int[highways];
		int[] toArray = new int[highways];
		int[] edgeprice = new int[highways];
		int fromNum = 0;
		int toNum = 0;
		int price = 0;
		
		for(int i = 0; i<highways; i++){
			fromNum = input.nextInt();
			fromArray[i] = fromNum;
			toNum = input.nextInt();
			toArray[i] = toNum;
			price = input.nextInt();
			edgeprice[i] = price;
			
			graph.edge[i].from = fromArray[i]-1;
			graph.edge[i].to = toArray[i]-1;
			graph.edge[i].weight = edgeprice[i];
			
		}
		graph.MST();
		
	}
	
	class Edge implements Comparable<Edge>{
		
		int weight;
		int from, to;
		
		@Override
		public int compareTo(Edge compare) {
			// TODO Auto-generated method stub
			return this.weight-compare.weight;
		}
	};
	
	class unionsubset{
		int parent;
		int rank;
	}
	
	void union(unionsubset subset[], int a, int b){
		int roota = find(subset, a);
		int rootb = find(subset, b);
		
		if(subset[roota].rank < subset[rootb].rank){
			subset[roota].parent = rootb;
		}else if(subset[roota].rank > subset[rootb].rank) {
			subset[rootb].parent = roota;
		}else{
			subset[rootb].parent = roota;
			subset[roota].rank++;
		}
	}
	
	cmsc401part2(int vertNums, int edgeNums){
		vertNum = vertNums;
		edgeNum = edgeNums;
		edge = new Edge[edgeNum];
		for(int i = 0; i<edgeNum; i++){
			edge[i] = new Edge();
		}
	}
	
	int find(unionsubset subset[], int i){
		if(subset[i].parent != i){
			subset[i].parent = find(subset, subset[i].parent);
		}
		
		return subset[i].parent;
	}
	
	void MST(){
		Edge result[] = new Edge[vertNum];
		int e = 0;
		int se = 0;
		for(se = 0; se<vertNum; se++){
			result[se] = new Edge();
		}
		
		//sort here
		Arrays.sort(edge);
		
		unionsubset subset[] = new unionsubset[vertNum];
		
		for(se = 0; se<vertNum;se++){
			subset[se] = new unionsubset();
		}
		for(int i = 0; i<vertNum; i++){
			subset[i].parent = i;
			subset[i].rank = 0;
		}
		se=0;
		
		while(e<vertNum - 1){
			Edge nextedge = new Edge();
			nextedge = edge[se++];
		
		int a = find(subset, nextedge.from);
		int b = find(subset, nextedge.to);
		
		
		if(a!=b){
			result[e++] = nextedge;
			union(subset, a , b);
		}
		}
		
		for (se = 0; se < e; se++){
            System.out.println((result[se].from+1)+ " -- " + (result[se].to+1) + " == " + result[se].weight);
		}
	}
}



/*
 5
 7
 3 38
 4 87
 5 98
 1 4 98
 5 4 45
 1 5 140
 4 3 87
 2 5 150
 3 5 109
 3 2 73
  
 */



