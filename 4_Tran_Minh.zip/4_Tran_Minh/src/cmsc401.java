
/////////////////////////////////////////////////
//     Minh Matthew Tran                       //
//     CMSC 401 Fall 2017                      //
//     Assignment #4                           //
/////////////////////////////////////////////////

import java.util.*;

public class cmsc401 {

	public static int[] calcCost(int[][] matrix, boolean[] visited, int[] cost, int[] motelcost_array) {

		for (int i = 0; i < matrix.length - 1; i++) {
			int min = Integer.MAX_VALUE;
			int index = -1;
			for (int k = 0; k < cost.length; k++) {
				if (visited[k] == false && cost[k] < min) {
					min = cost[k];
					index = k;
				}
			}
			int p = index;
			visited[p] = true;

			for (int o = 0; o < matrix.length; o++) {
				if (!visited[o] && matrix[p][o] != 0 && cost[p] != Integer.MAX_VALUE) {
					if (cost[p] + matrix[p][o] + motelcost_array[p] < cost[o]) {
						cost[o] = cost[p] + matrix[p][o] + motelcost_array[p];
					}
				}
			}
		}
		return cost;
	}

	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);

		int cities = input.nextInt();
		int highways = input.nextInt();

		int[] citynum_array = new int[cities];
		citynum_array[0] = 0;
		citynum_array[1] = 0;
		int[] motelcost_array = new int[cities];
		motelcost_array[0] = 0;
		motelcost_array[1] = 0;

		int from = 0;
		int to = 1;

		int citynum = 0;
		int motelcost = 0;

		for (int i = 0; i < cities - 2; i++) {
			citynum = input.nextInt();
			citynum_array[i + 2] = citynum;
			motelcost = input.nextInt();
			motelcost_array[i + 2] = motelcost;
		}

		int[] fromArray = new int[highways];
		int[] toArray = new int[highways];
		int[] edgeprice = new int[highways];
		int[][] matrix = new int[cities][cities];
		int[] cost = new int[matrix.length];
		boolean[] visited = new boolean[matrix.length];

		int fromNum = 0;
		int toNum = 0;
		int price = 0;

		for (int i = 0; i < highways; i++) {
			fromNum = input.nextInt() - 1;
			fromArray[i] = fromNum + 1;
			toNum = input.nextInt() - 1;
			toArray[i] = toNum + 1;

			price = input.nextInt();
			edgeprice[i] = price;
			matrix[fromNum][toNum] = price;
			matrix[toNum][fromNum] = matrix[fromNum][toNum];
		}
		for (int i = 0; i < matrix.length; i++) {
			cost[i] = Integer.MAX_VALUE;
			visited[i] = false;
		}
		cost[from] = 0;

		int[] result = new int[cost.length];

		result = calcCost(matrix, visited, cost, motelcost_array);

		System.out.println(result[to]);

	}

}

/*
  5 7 3 38 4 87 5 98 1 4 98 5 4 45 1 5 140 4 3 87 2 5 150 3 5 109 3 2 73
 * 
 * 
 * input 2
 * 
 9 13 3 24 4 52 5 16 6 87 7 44 8 64 9 71 1 6 115 4 7 80 5 2 71 7 3 74 9 3 87 1
 8 132 6 2 89 8 4 121 4 2 67 3 5 91 9 6 38 1 3 50 5 7 79
 * 
 * 
 * 
 */
